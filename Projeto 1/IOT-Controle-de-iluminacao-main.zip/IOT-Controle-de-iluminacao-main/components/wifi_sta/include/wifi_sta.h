#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void wifi_sta_start(void);

#ifdef __cplusplus
}
#endif
