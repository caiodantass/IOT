#pragma once

#define BAT_WIFI_SSID       "MERCUSYS_7E02"
#define BAT_WIFI_PASSWORD   "70960594"
#define BAT_MQTT_BROKER_URI "mqtt://192.168.1.107:1883"
#define BAT_BUTTON_GPIO     4

#define GOTHAM_TOPIC_SIGNAL "gotham/dpgc/berg_caio/batsignal"
#define GOTHAM_TOPIC_STATUS "gotham/dpgc/berg_caio/status"
#define GOTHAM_MSG_SIGNAL_ON  "BAT_SIGNAL_ON"
#define GOTHAM_MSG_SIGNAL_OFF "BAT_SIGNAL_OFF"
#define GOTHAM_DEVICE_ID      "bat_button"
#define GOTHAM_HEARTBEAT_MS   30000
