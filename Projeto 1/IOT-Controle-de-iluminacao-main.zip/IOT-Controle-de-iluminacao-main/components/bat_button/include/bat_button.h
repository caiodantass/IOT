#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void bat_button_init(void);
void bat_button_start(void);

#ifdef __cplusplus
}
#endif
